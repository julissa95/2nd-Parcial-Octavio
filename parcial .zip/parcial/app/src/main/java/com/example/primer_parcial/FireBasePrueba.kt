package com.example.primer_parcial

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_fire_base_prueba.*
import kotlinx.android.synthetic.main.activity_fire_base_social_chat.*
import kotlinx.android.synthetic.main.activity_fire_base_social_chat.btnEnviar
import kotlinx.android.synthetic.main.activity_fire_base_social_chat.txtDestino
import kotlinx.android.synthetic.main.activity_fire_base_social_chat.txtId
import kotlinx.android.synthetic.main.activity_fire_base_social_chat.txtMensaje
import kotlinx.android.synthetic.main.activity_fire_base_social_chat.txtUsuario
import kotlinx.android.synthetic.main.activity_login.*

class FireBasePrueba : AppCompatActivity() {

    private lateinit var database: DatabaseReference// ...
    private lateinit var postReference: DatabaseReference
    private lateinit var postKey: String
    private var postListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fire_base_prueba)

        //btnEnviar.setOnClickListener {

            val txtMensaje = findViewById<TextView>(R.id.txtMensaje)
            val txtId = findViewById<TextView>(R.id.txtId)
            val txtUsuario = findViewById<TextView>(R.id.txtUsuario)
            val txtDestino = findViewById<TextView>(R.id.txtDestino)

            postReference = FirebaseDatabase.getInstance().reference
                .child("mensajes")

            val btnEnviar = findViewById<Button>(R.id.btnEnviar)

            btnEnviar.setOnClickListener {
                val intentUno = Intent(this, Login::class.java)
                startActivity(intentUno)

                // [START initialize_database_ref]
                database = FirebaseDatabase.getInstance().reference
                // [END initialize_database_ref]
                val key = database.child("mensajes").push().key

                if (key == null) {
                    // Log.w("error", "Couldn't get push key for posts")
                    Toast.makeText(this, "error", Toast.LENGTH_SHORT).show()

                }

                val destino = this.txtDestino.getText().toString()
                val uid = this.txtId.getText().toString()
                val usuario = this.txtUsuario.getText().toString()
                val mensaje = this.txtMensaje.getText().toString()
                val post = Post(uid, usuario, destino, mensaje)
                val postValues = post.toMap()

                val childUpdates = HashMap<String, Any>()
                childUpdates["/mensajes/$destino/$key"] = postValues
                childUpdates["/mensajes_usuario/$uid/$destino/$key"] = postValues

                database.updateChildren(childUpdates)

            }


        }

        // [START post_class]
        @IgnoreExtraProperties
        data class Post(
            var uid: String? = "",
            var emisor: String? = "",
            var destino: String? = "",
            var mensaje: String? = "",
            var starCount: Int = 0,
            var stars: MutableMap<String, Boolean> = HashMap()
        ) {

            // [START post_to_map]
            @Exclude
            fun toMap(): Map<String, Any?> {
                return mapOf(
                    "uid" to uid,
                    "emisor" to emisor,
                    "destino" to destino,
                    "mensaje" to mensaje

                )
            }
        }
    }


















