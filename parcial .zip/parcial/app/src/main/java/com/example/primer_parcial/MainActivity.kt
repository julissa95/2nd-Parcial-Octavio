package com.example.primer_parcial

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Obtain the FirebaseAnalytics instance(Evento)
        //val analytics : firebaseAnalytics = FirebaseAnalytics.getInstance(this)
        //val bundle = Bundle()
        //bundle.putString( "Message", "Integracion de Firebase completa")
        //analytics.logEvent("InitScreen" ,bundle )

        val btnWelcome=findViewById<Button>(R.id.btnWelcome)
        try {
            btnWelcome.setOnClickListener {
                val intentUno = Intent(this, FireBasePrueba::class.java)
                startActivity(intentUno)
                //finish()
            }
        }catch (e:Throwable){
                Toast.makeText(this, "Se produjo un error" + e.message,Toast.LENGTH_SHORT).show()
            }
    }
}

